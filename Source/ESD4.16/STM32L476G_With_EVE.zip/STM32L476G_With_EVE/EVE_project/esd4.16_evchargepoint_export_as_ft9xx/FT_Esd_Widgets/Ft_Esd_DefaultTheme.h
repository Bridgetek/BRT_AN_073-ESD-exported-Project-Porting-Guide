
#ifndef FT_ESD_DEFAULTTHEME_H
#define FT_ESD_DEFAULTTHEME_H
#include "Ft_DataTypes.h"
#include "Ft_Esd_Theme.h"

extern Ft_Esd_Theme Ft_Esd_DefaultTheme;

#endif

/* Nothing beyond this */
