
#include "Esd_Base.h"

ESD_CORE_EXPORT void Esd_Noop(void *context)
{
	// no-op
}

/* end of file */
