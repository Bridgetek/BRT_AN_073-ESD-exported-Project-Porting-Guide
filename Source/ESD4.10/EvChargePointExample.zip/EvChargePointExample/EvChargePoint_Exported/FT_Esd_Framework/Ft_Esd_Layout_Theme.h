/*
Ft_Esd_Layout_Theme
C Source
*/
#ifndef Ft_Esd_Layout_Theme__H
#define Ft_Esd_Layout_Theme__H

#include "Ft_Esd.h"

// Layout which sets the specified theme during the render pass of it's child widgets. Behaves like Fill Layout otherwise

#endif /* Ft_Esd_Layout_Theme__H */

/* end of file */
