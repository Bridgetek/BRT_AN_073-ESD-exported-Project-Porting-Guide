#include "Ft_Esd.h"
#include "AnimationWidget.h"

#include "Ft_Esd_CoCmd.h"

#define ANIM_ADDR 10165312
#define FRAME_COUNT 414

ESD_METHOD(AnimationWidget_Render_Signal, Context = AnimationWidget)
void AnimationWidget_Render_Signal(AnimationWidget *context)
{
	Ft_Gpu_CoCmd_AnimXY(Ft_Esd_Host, 1,
	    context->Widget.GlobalX + (context->Widget.GlobalWidth >> 1),
	    context->Widget.GlobalY + (context->Widget.GlobalHeight >> 1));
	Ft_Gpu_CoCmd_AnimDraw(Ft_Esd_Host, 1);
}

ESD_METHOD(AnimationWidget_Start_Signal, Context = AnimationWidget)
void AnimationWidget_Start_Signal(AnimationWidget *context)
{
	Ft_Gpu_CoCmd_AnimStart(Ft_Esd_Host, 1, ANIM_ADDR, ANIM_LOOP);
	Ft_Gpu_Hal_WaitCmdFifoEmpty(Ft_Esd_Host);
}

ESD_METHOD(AnimationWidget_End_Signal, Context = AnimationWidget)
void AnimationWidget_End_Signal(AnimationWidget *context)
{
	Ft_Gpu_CoCmd_AnimStop(Ft_Esd_Host, 1);
}

/* end of file */
