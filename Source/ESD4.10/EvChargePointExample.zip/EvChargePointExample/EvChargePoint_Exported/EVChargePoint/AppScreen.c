#include "Ft_Esd.h"
#include "AppScreen.h"

#include "Ft_Esd_Dl.h"
#include "Ft_Esd_GpuAlloc.h"

void Esd_ShowLogo();

ESD_METHOD(AppScreen_ShowLogo, Context = AppScreen)
void AppScreen_ShowLogo(AppScreen *context)
{
	Esd_ShowLogo();
}
